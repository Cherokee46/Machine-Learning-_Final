# Forecasting Lab

## Quick Start
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
